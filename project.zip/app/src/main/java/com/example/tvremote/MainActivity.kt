package com.example.tvremote

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue

/** Controle remoto (Wi-Fi) + Air Mouse (Bluetooth) na mesma tela, em estilo "vidro". */
class MainActivity : Activity(), SensorEventListener {
    // Wi-Fi
    private lateinit var ip: EditText
    private lateinit var tvList: LinearLayout
    private lateinit var logView: TextView
    private lateinit var wifiPill: TextView
    private lateinit var btPill: TextView
    private lateinit var main: LinearLayout
    private lateinit var settings: ScrollView
    private var conn: RemoteConn? = null
    private var disc: Discovery? = null
    @Volatile private var wifiOk = false
    private val found = HashSet<String>()
    private val codeQ = LinkedBlockingQueue<String>()
    private val logBuf = StringBuilder()

    // Bluetooth (mouse)
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var sm: SensorManager
    @Volatile private var holding = false
    private var sens = 12f
    private var upright = false
    private var accX = 0f
    private var accY = 0f

    private val descriptor: ByteArray = intArrayOf(
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x09, 0x01, 0xA1, 0x00, 0x05, 0x09, 0x19, 0x01, 0x29, 0x03,
        0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03,
        0x81, 0x06, 0xC0, 0xC0
    ).map { it.toByte() }.toByteArray()

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            if (!registered) { setPill(btPill, false, "Mouse"); return }
            log("Mouse Bluetooth pronto")
            val addr = getSharedPreferences("p", MODE_PRIVATE).getString("bt", null) ?: return
            val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ad?.bondedDevices?.firstOrNull { it.address == addr }?.let { hid?.connect(it) }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) { host = device; setPill(btPill, true, "Mouse") }
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { host = null; setPill(btPill, false, "Mouse") }
        }
    }

    // ---------- estilo ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun log(s: String) = runOnUiThread {
        logBuf.append(s).append('\n')
        if (logBuf.length > 1500) logBuf.delete(0, logBuf.length - 1500)
        logView.text = logBuf.toString()
    }

    /** kind: 0 = vidro escuro, 1 = vidro azul, 2 = vidro claro */
    private fun glass(r: Int, kind: Int = 0): GradientDrawable {
        val c = when (kind) {
            1 -> intArrayOf(0xF2347BFF.toInt(), 0xF21F55E0.toInt())
            2 -> intArrayOf(0x99FFFFFF.toInt(), 0x66FFFFFF.toInt())
            else -> intArrayOf(0xE63C3C41.toInt(), 0xEB1E1E22.toInt())
        }
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, c).apply {
            cornerRadius = dp(r).toFloat()
            setStroke(dp(1), if (kind == 2) 0xB3FFFFFF.toInt() else 0x40FFFFFF)
        }
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { x, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    private fun btn(t: String, h: Int = 52, kind: Int = 0, onClick: () -> Unit): Button = Button(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; isAllCaps = false; stateListAnimator = null
        background = glass(18, kind)
        pressFx(this)
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(h), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun key(t: String, code: Int, h: Int = 52) = btn(t, h) {
        val c = conn
        if (c == null || !wifiOk) log("TV não conectada (toque em ⚙)") else c.key(code)
    }

    private fun spacer(h: Int = 52) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, dp(h), 1f) }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun pill(label: String) = TextView(this).apply {
        text = "○ $label"; setTextColor(0xFFFFB4B4.toInt()); textSize = 14f; gravity = Gravity.CENTER
        background = glass(22)
        layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun setPill(p: TextView, ok: Boolean, label: String) = runOnUiThread {
        p.text = (if (ok) "● " else "○ ") + label
        p.setTextColor(if (ok) 0xFF7CFFB2.toInt() else 0xFFFFB4B4.toInt())
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; setTextColor(0xFF6B7280.toInt()); textSize = 13f; setPadding(dp(4), dp(12), 0, dp(2))
    }

    // ---------- tela ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        window.statusBarColor = 0xFFF4F6FB.toInt()
        window.navigationBarColor = 0xFFF2E9F7.toInt()
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        ip = EditText(this).apply {
            hint = "IP da TV (ex: 192.168.0.20)"
            setText(prefs.getString("ip", ""))
            setTextColor(0xFF1C1C1E.toInt()); setHintTextColor(0xFF8A94A0.toInt())
            background = glass(14, 2); setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        tvList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        logView = TextView(this).apply { setTextColor(0xFF6B7280.toInt()); textSize = 12f }
        wifiPill = pill("TV")
        btPill = pill("Mouse")

        val gear = Button(this).apply {
            text = "⚙"; setTextColor(Color.WHITE); textSize = 20f; stateListAnimator = null
            background = glass(22); pressFx(this)
            setOnClickListener { showSettings(true) }
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(44)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
        }

        // área de toque do mouse
        var lx = 0f; var ly = 0f; var downT = 0L; var moved = 0f
        val pad = TextView(this).apply {
            text = "Touchpad\ndeslize para mover · toque = clique"
            setTextColor(0xFF6B7280.toInt()); gravity = Gravity.CENTER; textSize = 13f
            background = glass(22, 2)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { setMargins(dp(4), dp(6), dp(4), dp(6)) }
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; downT = e.eventTime; moved = 0f }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.x - lx; val dy = e.y - ly
                        lx = e.x; ly = e.y; moved += Math.abs(dx) + Math.abs(dy)
                        send((dx * 1.2f).toInt(), (dy * 1.2f).toInt())
                    }
                    MotionEvent.ACTION_UP -> if (moved < dp(10) && e.eventTime - downT < 250) click(1)
                }
                true
            }
        }

        val hold = Button(this).apply {
            text = "SEGURE E APONTE"; setTextColor(Color.WHITE); textSize = 17f; stateListAnimator = null
            background = glass(26, 1)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(68)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { holding = true; accX = 0f; accY = 0f; v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> holding = false
                }
                true
            }
        }

        main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row(wifiPill, btPill, gear))
            addView(row(spacer(), key("▲", 19), spacer()))
            addView(row(key("◀", 21), key("OK", 23), key("▶", 22)))
            addView(row(spacer(), key("▼", 20), spacer()))
            addView(row(key("Voltar", 4, 46), key("Home", 3, 46), key("Menu", 82, 46), key("Power", 26, 46)))
            addView(row(key("Vol −", 25, 46), key("Mudo", 164, 46), key("Vol +", 24, 46), key("⏯", 85, 46)))
            addView(pad)
            addView(row(btn("Clique", 46) { click(1) }, btn("Dir.", 46) { click(2) },
                btn("▲", 46) { send(0, 0, 0, 3) }, btn("▼", 46) { send(0, 0, 0, -3) }))
            addView(hold)
        }

        val seek = SeekBar(this).apply {
            max = 30; progress = 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sens = 2f + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val modeBtn = btn("Celular: deitado", 46) {}
        modeBtn.setOnClickListener {
            upright = !upright
            modeBtn.text = if (upright) "Celular: em pé" else "Celular: deitado"
        }

        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label("TV (Wi-Fi)"))
            addView(ip)
            addView(row(btn("Buscar TV na rede", 48) { startDiscovery() }))
            addView(tvList)
            addView(row(btn("Parear", 48) { startPair() }, btn("Conectar", 48) { connect() }))
            addView(label("Mouse (Bluetooth) — pareie a TV antes nas configurações de Bluetooth do celular"))
            addView(row(btn("Conectar mouse à TV", 48) { pickDevice() }))
            addView(row(btn("Tornar visível", 48) { makeVisible() }, modeBtn))
            addView(label("Sensibilidade do air mouse"))
            addView(seek)
            addView(label("Registro"))
            addView(logView)
            addView(row(btn("Fechar", 52, 1) { showSettings(false) }))
        }
        settings = ScrollView(this).apply { addView(inner); visibility = View.GONE }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFFF4F6FB.toInt(), 0xFFE3E8F5.toInt(), 0xFFF2E9F7.toInt())
            )
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(main, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(settings, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)

        val saved = prefs.getString("ip", "") ?: ""
        if (saved.isEmpty()) showSettings(true) else connect()
        startDiscovery()

        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        else setupBt()
    }

    private fun showSettings(show: Boolean) {
        settings.visibility = if (show) View.VISIBLE else View.GONE
        main.visibility = if (show) View.GONE else View.VISIBLE
        holding = false
    }

    // ---------- Wi-Fi ----------
    private fun startDiscovery() {
        disc?.stop()
        found.clear()
        tvList.removeAllViews()
        disc = Discovery(this) { n, a -> onTv(n, a) }
        try { disc?.start(); log("Procurando TVs na rede...") } catch (e: Exception) { log("Busca falhou: ${e.message}") }
    }

    private fun onTv(name: String, addr: String) = runOnUiThread {
        if (!found.add(addr)) return@runOnUiThread
        log("TV encontrada: $name ($addr)")
        tvList.addView(row(btn("$name · $addr", 48) { ip.setText(addr); log("IP definido: $addr") }))
        if (found.size == 1) {
            ip.setText(addr)
            if (!wifiOk) connect()
        }
    }

    private fun host(): String? {
        val h = ip.text.toString().trim()
        if (h.isEmpty()) { log("Digite o IP da TV"); return null }
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("ip", h).apply()
        return h
    }

    private fun askCode() {
        val et = EditText(this).apply {
            hint = "Código de 6 caracteres"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        }
        AlertDialog.Builder(this).setTitle("Código que aparece na TV").setView(et).setCancelable(false)
            .setPositiveButton("OK") { _, _ -> codeQ.put(et.text.toString().trim()) }
            .setNegativeButton("Cancelar") { _, _ -> codeQ.put("") }
            .show()
    }

    private fun startPair() {
        val h = host() ?: return
        codeQ.clear()
        Thread {
            try {
                log("Pareando com $h... olhe o código na TV")
                val ok = Pairing(this, h) { s -> log(s) }.start {
                    runOnUiThread { askCode() }
                    codeQ.take().ifEmpty { null }
                }
                log(if (ok) "Pareado! Toque em Conectar" else "Pareamento cancelado")
            } catch (e: Exception) {
                log("Erro no pareamento: ${e.message}")
            }
        }.start()
    }

    private fun connect() {
        val h = host() ?: return
        conn?.close()
        conn = RemoteConn(this, h, { s -> log(s) }) { ok ->
            wifiOk = ok
            setPill(wifiPill, ok, "TV")
        }
        conn?.connect()
        log("Conectando à TV...")
    }

    // ---------- Bluetooth (mouse) ----------
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) setupBt()
        else log("Sem permissão de Bluetooth. Autorize nas configurações do app.")
    }

    private fun setupBt() {
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { log("Ligue o Bluetooth do celular para usar o mouse."); return }
        val ok = ad.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Controle TV", "Air mouse", "Controle TV", BluetoothHidDevice.SUBCLASS1_MOUSE, descriptor
                )
                if (!h.registerApp(sdp, null, null, exec, cb)) log("Seu celular não aceitou virar um mouse Bluetooth.")
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) log("Este celular não suporta mouse Bluetooth.")
    }

    private fun pickDevice() {
        val h = hid
        if (h == null) { log("Aguarde o mouse ficar pronto (ou ligue o Bluetooth)."); return }
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val list = ad.bondedDevices.toList()
        if (list.isEmpty()) { log("Nenhum aparelho pareado. Pareie a TV pelas configurações de Bluetooth do celular."); return }
        AlertDialog.Builder(this).setTitle("Conectar o mouse a qual aparelho?")
            .setItems(list.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                getSharedPreferences("p", MODE_PRIVATE).edit().putString("bt", list[i].address).apply()
                log("Conectando mouse a ${list[i].name ?: list[i].address}...")
                h.connect(list[i])
            }.show()
    }

    private fun makeVisible() {
        try {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
        } catch (e: Exception) { log("Não consegui ficar visível: ${e.message}") }
    }

    private fun send(dx: Int, dy: Int, buttons: Int = 0, wheel: Int = 0) {
        val h = hid ?: return
        val d = host ?: return
        h.sendReport(d, 0, byteArrayOf(
            buttons.toByte(), dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), wheel.coerceIn(-127, 127).toByte()
        ))
    }

    private fun click(mask: Int) { send(0, 0, mask); send(0, 0, 0) }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() { sm.unregisterListener(this); holding = false; super.onPause() }

    override fun onSensorChanged(e: SensorEvent) {
        if (!holding) return
        val yaw = if (upright) e.values[1] else e.values[2]
        accX += -yaw * sens
        accY += -e.values[0] * sens
        val ix = accX.toInt(); val iy = accY.toInt()
        accX -= ix; accY -= iy
        if (ix != 0 || iy != 0) send(ix, iy)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDestroy() {
        conn?.close(); disc?.stop()
        try {
            hid?.unregisterApp()
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {}
        exec.shutdown()
        super.onDestroy()
    }
}
