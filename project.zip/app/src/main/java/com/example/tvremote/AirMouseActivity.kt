package com.example.tvremote

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import java.util.concurrent.Executors

/** Celular vira um mouse Bluetooth (HID). A TV mostra o ponteiro na tela. */
class AirMouseActivity : Activity(), SensorEventListener {
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val exec = Executors.newSingleThreadExecutor()
    private lateinit var info: TextView
    private lateinit var sm: SensorManager
    @Volatile private var holding = false
    private var sens = 12f
    private var upright = false
    private var accX = 0f
    private var accY = 0f

    private val descriptor: ByteArray = intArrayOf(
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x09, 0x01, 0xA1, 0x00, 0x05, 0x09, 0x19, 0x01, 0x29, 0x03,
        0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03,
        0x81, 0x06, 0xC0, 0xC0
    ).map { it.toByte() }.toByteArray()

    private val cb = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            say(if (registered) "Mouse pronto. Toque em \"Tornar visível\" e pareie pela TV." else "Mouse não registrado")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) { host = device; say("● Conectado à TV por Bluetooth") }
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { host = null; say("○ Desconectado") }
        }
    }

    private fun say(s: String) = runOnUiThread { info.text = s }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun btn(t: String, onClick: () -> Unit): Button = Button(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 16f; isAllCaps = false
        background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFF232A33.toInt()) }
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); onClick() }
        layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    /** Envia um relatório de mouse: botões, dx, dy, rolagem. */
    private fun send(dx: Int, dy: Int, buttons: Int = 0, wheel: Int = 0) {
        val h = hid ?: return
        val d = host ?: return
        h.sendReport(d, 0, byteArrayOf(
            buttons.toByte(), dx.coerceIn(-127, 127).toByte(), dy.coerceIn(-127, 127).toByte(), wheel.coerceIn(-127, 127).toByte()
        ))
    }

    private fun click(mask: Int) { send(0, 0, mask); send(0, 0, 0) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        info = TextView(this).apply {
            text = "Iniciando..."; setTextColor(0xFF8A94A0.toInt()); textSize = 14f; gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }

        val hold = Button(this).apply {
            text = "SEGURE E APONTE"; setTextColor(Color.WHITE); textSize = 20f
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFF2E5BFF.toInt()) }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(96)).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { holding = true; accX = 0f; accY = 0f; v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> holding = false
                }
                true
            }
        }

        var lx = 0f; var ly = 0f; var downT = 0L; var moved = 0f
        val pad = TextView(this).apply {
            text = "Touchpad: deslize aqui\n(toque rápido = clique)"; setTextColor(0xFF8A94A0.toInt()); gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(0xFF1A2028.toInt()) }
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y; downT = e.eventTime; moved = 0f }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.x - lx; val dy = e.y - ly
                        lx = e.x; ly = e.y; moved += Math.abs(dx) + Math.abs(dy)
                        send((dx * 1.2f).toInt(), (dy * 1.2f).toInt())
                    }
                    MotionEvent.ACTION_UP -> if (moved < dp(10) && e.eventTime - downT < 250) click(1)
                }
                true
            }
        }

        val seek = SeekBar(this).apply {
            max = 30; progress = 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { sens = 2f + p }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val label = TextView(this).apply { text = "Sensibilidade"; setTextColor(0xFF8A94A0.toInt()); textSize = 12f }

        val modeBtn = btn("Celular: deitado") {}
        modeBtn.setOnClickListener {
            upright = !upright
            modeBtn.text = if (upright) "Celular: em pé" else "Celular: deitado"
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(16), dp(24), dp(16), dp(24))
            addView(info)
            addView(row(btn("Tornar visível (parear)") { makeVisible() }))
            addView(row(btn("Conectar a aparelho pareado") { pickDevice() }))
            addView(hold)
            addView(pad)
            addView(row(btn("Clique") { click(1) }, btn("Voltar (clique direito)") { click(2) }))
            addView(row(btn("Rolar ▲") { send(0, 0, 0, 3) }, btn("Rolar ▼") { send(0, 0, 0, -3) }, modeBtn))
            addView(label)
            addView(seek)
        }
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
        else setup()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) setup()
        else say("Sem permissão de Bluetooth. Autorize nas configurações do app.")
    }

    private fun setup() {
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (ad == null || !ad.isEnabled) { say("Ligue o Bluetooth do celular e volte aqui."); return }
        val ok = ad.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Controle TV", "Air mouse", "Controle TV", BluetoothHidDevice.SUBCLASS1_MOUSE, descriptor
                )
                if (!h.registerApp(sdp, null, null, exec, cb)) say("Seu celular não aceitou virar um mouse Bluetooth.")
            }
            override fun onServiceDisconnected(profile: Int) { hid = null }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) say("Este celular não suporta mouse Bluetooth.")
    }

    /** Inicia a conexão com um aparelho já pareado (ex.: a TV pareada pelas configurações do celular). */
    private fun pickDevice() {
        val h = hid
        if (h == null) { say("Aguarde o mouse ficar pronto."); return }
        val ad = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val list = ad.bondedDevices.toList()
        if (list.isEmpty()) { say("Nenhum aparelho pareado. Pareie a TV pelas configurações de Bluetooth do celular."); return }
        AlertDialog.Builder(this).setTitle("Conectar a qual aparelho?")
            .setItems(list.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                say("Conectando a ${list[i].name ?: list[i].address}...")
                h.connect(list[i])
            }.show()
    }

    private fun makeVisible() {
        try {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120))
            say("Agora, na TV: Configurações > Controles remotos e acessórios > Adicionar acessório, e escolha \"${android.os.Build.MODEL}\".")
        } catch (e: Exception) { say("Não consegui ficar visível: ${e.message}") }
    }

    override fun onResume() {
        super.onResume()
        sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() { sm.unregisterListener(this); holding = false; super.onPause() }

    override fun onSensorChanged(e: SensorEvent) {
        if (!holding) return
        val yaw = if (upright) e.values[1] else e.values[2]
        accX += -yaw * sens
        accY += -e.values[0] * sens
        val ix = accX.toInt(); val iy = accY.toInt()
        accX -= ix; accY -= iy
        if (ix != 0 || iy != 0) send(ix, iy)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDestroy() {
        try {
            hid?.unregisterApp()
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {}
        exec.shutdown()
        super.onDestroy()
    }
}
