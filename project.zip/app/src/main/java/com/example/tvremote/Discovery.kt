package com.example.tvremote

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import java.net.Inet4Address

/** Procura TVs Android/Google TV na rede (mDNS). Só acha aparelhos na mesma rede do celular. */
class Discovery(ctx: Context, private val onFound: (name: String, ip: String) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var listener: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var busy = false

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                synchronized(this@Discovery) { queue.addLast(s) }
                next()
            }
        }
        listener = l
        nsd.discoverServices("_androidtvremote2._tcp", NsdManager.PROTOCOL_DNS_SD, l)
    }

    @Synchronized
    private fun next() {
        if (busy) return
        val s = queue.removeFirstOrNull() ?: return
        busy = true
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) { done() }
                override fun onServiceResolved(i: NsdServiceInfo) {
                    val a = i.host
                    if (a is Inet4Address) onFound(i.serviceName, a.hostAddress ?: "")
                    done()
                }
            })
        } catch (e: Exception) { done() }
    }

    @Synchronized
    private fun done() { busy = false; next() }

    fun stop() {
        listener?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listener = null
    }
}
